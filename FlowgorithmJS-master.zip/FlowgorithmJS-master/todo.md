# To-do

- [x] Allargare in altezza la figura della condizione quando il testo è superiore di un TOT di caratteri e all'interno ci sono operatori logici
- [x] Rivedere il calcolo della larghezza delle figure di I/O perchè un testo lungo esce dai bordi
- [x] Unire più INPUT consecutivi in uno solo
- [x] Aumentare dinamicamente la larghezza dei rami TRUE e FALSE in base alla larghezza della sequenza in essi contenuta
- [x] Iterazioni precondizionali indefinite
- [x] Iterazioni postcondizionali indefinite
- [x] Iterazioni precondizionali definite
- [x] Gestione di condizioni con all'interno entrambi gli operatori logici && e ||
- [x] Gestione funzioni
- [x] Migliorare posizionamento funzioni
- [x] Add pre-load and post-load events
- [x] Add "viewDesc" and "itMode" settings to "drawLocal" page